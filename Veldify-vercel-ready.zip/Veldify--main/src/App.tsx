/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { LoadingScreen } from "./components/LoadingScreen";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Generator } from "./components/Generator";
import { Footer } from "./components/Footer";
import { OutputResult } from "./types";
import { LanguageProvider, useLanguage } from "./i18n";

function AppContent() {
  const [showLoading, setShowLoading] = useState(true);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<OutputResult | null>(null);
  const [currentFile, setCurrentFile] = useState<File | null>(null);

  const { lang } = useLanguage();

  const handleUploadClick = () => {
    document.getElementById("generator-section")?.scrollIntoView({ behavior: "smooth" });
  };

  const toBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });

  const getAspectRatio = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        const w = img.width;
        const h = img.height;
        URL.revokeObjectURL(url);
        const ratio = w / h;
        if (ratio > 1.8) resolve("16:9");
        else if (ratio > 1.4) resolve("3:2");
        else if (ratio > 1.2) resolve("4:3");
        else if (ratio > 0.9) resolve("1:1");
        else if (ratio > 0.7) resolve("3:4");
        else if (ratio > 0.6) resolve("2:3");
        else resolve("9:16");
      };
      img.onerror = () => resolve("1:1");
      img.src = url;
    });
  };

  const handleGenerate = async (file: File, isVariation = false, detailLevel = 'ultra', controls: any) => {
    try {
      setLoading(true);
      if (!isVariation) setCurrentFile(file);
      const targetFile = isVariation ? currentFile : file;
      if (!targetFile) return;

      const base64Image = await toBase64(targetFile);
      const aspectRatio = await getAspectRatio(targetFile);
      
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          image: base64Image,
          mimeType: targetFile.type,
          language: lang,
          isVariation,
          detailLevel,
          aspectRatio,
          controls
        }),
      });

      if (!response.ok) {
        throw new Error(await response.text());
      }

      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error("Failed to generate prompt:", error);
      alert("Analysis Engine Error: Failed to generate prompts. Check console for details.");
    } finally {
      setLoading(false);
    }
  };

  if (showLoading) {
    return <LoadingScreen onComplete={() => setShowLoading(false)} />;
  }

  return (
    <div className="min-h-screen flex flex-col font-sans bg-primary-black text-white relative">
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(var(--color-border-dark) 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
      <Navbar />
      <main className="flex-1 relative z-10">
        <Hero onUploadClick={handleUploadClick} />
        <Generator result={result} loading={loading} onUpload={(f, dl, c) => handleGenerate(f, false, dl, c)} onVariation={(dl, c) => currentFile && handleGenerate(currentFile, true, dl, c)} />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}

