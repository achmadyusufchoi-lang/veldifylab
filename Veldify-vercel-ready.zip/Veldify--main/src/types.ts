export interface OutputResult {
  mainPrompt: string;
  negativePrompt: string;
  freyParameters: string[];
  combinedPrompt: string;
}
