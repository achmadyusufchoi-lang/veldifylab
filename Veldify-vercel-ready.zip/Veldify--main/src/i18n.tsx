import { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'id';

export const translations = {
  en: {
    nav: {
      generator: "Generator",
      templates: "Prompt Templates",
      docs: "Documentation",
      pricing: "Pricing",
      generate: "Generate Prompt"
    },
    hero: {
      badge: "Veldify Engine v2.4 Online",
      title1: "Generate Consistent AI Prompts",
      title2: "From Any Image",
      desc: "Upload a reference photo and instantly generate identity-locked prompts that preserve face, hairstyle, outfit, pose, lighting, and quality across generations in hyper-realistic style.",
      upload: "Upload Image",
      demo: "Try Demo"
    },
    gen: {
      drop: "Drop reference image here",
      supported: "PNG, JPG up to 10MB",
      scan: "AI Intelligence Scan",
      engine: "v2.4 engine",
      faceIdentity: "Face Identity Lock",
      expressionLock: "Micro-Expression Match",
      framingLock: "Subject Framing Match",
      povLock: "Camera POV Match",
      skinRealism: "Skin Realism & Texture",
      hairGeo: "Hairstyle Geometry",
      outfitTex: "Outfit Texture Match",
      poseLang: "Pose & Body Language",
      rawPhoto: "Raw Photo Quality Match",
      control: "Engine Control",
      faceCons: "Face Consistency",
      poseCons: "Pose Consistency",
      outfitPres: "Outfit Preservation",
      lightQual: "Lighting & Quality Match",
      detailLevel: "Prompt Detail Level",
      levels: {
        basic: "Basic",
        detailed: "Detailed",
        ultra: "Ultra Detailed"
      },
      tabs: {
        combined: "Prompt Siap Pakai",
        main: "Prompt Utama",
        negative: "Negative Prompt",
        frey: "Kunci Frey"
      },
      ready: "Ready",
      running: "Running Scan...",
      waiting: "Waiting for Scan",
      waitDesc: "Output data will appear here once the engine completes processing.",
      copyAll: "Copy All",
      copyContent: "Copy Content"
    },
    export: {
      profile: "Engine Profile",
      btn: "EXPORT JSON",
      variation: "VARIATION"
    },
    footer: {
      rights: "© 2026 VELDIFY ENGINE LAB",
      tagline: "PRECISION PROMPT ENGINEERING PLATFORM",
      stable: "Neural Engine: Stable",
      privacy: "Privacy Policy",
      terms: "Terms of Service"
    }
  },
  id: {
    nav: {
      generator: "Generator",
      templates: "Template Prompt",
      docs: "Dokumentasi",
      pricing: "Harga",
      generate: "Hasilkan Prompt"
    },
    hero: {
      badge: "Veldify Engine v2.4 Online",
      title1: "Hasilkan Prompt AI Konsisten",
      title2: "Dari Gambar Apapun",
      desc: "Unggah foto referensi dan hasilkan prompt terkunci-identitas yang mempertahankan wajah, gaya rambut, pakaian, pose, pencahayaan, dan kualitas ke dalam gaya hiper-realistis.",
      upload: "Unggah Gambar",
      demo: "Coba Demo"
    },
    gen: {
      drop: "Letakkan gambar referensi di sini",
      supported: "PNG, JPG maksimal 10MB",
      scan: "Pemindaian Kecerdasan AI",
      engine: "engine v2.4",
      faceIdentity: "Kunci Identitas Wajah",
      expressionLock: "Kunci Ekspresi Wajah",
      framingLock: "Pencocokan Ukuran Subjek",
      povLock: "Pencocokan Sudut Pandang Kamera",
      skinRealism: "Realisme & Tekstur Kulit",
      hairGeo: "Geometri Gaya Rambut",
      outfitTex: "Pencocokan Tekstur Pakaian",
      poseLang: "Pose & Bahasa Tubuh",
      rawPhoto: "Kualitas Foto Asli",
      control: "Kontrol Engine",
      faceCons: "Konsistensi Wajah",
      poseCons: "Konsistensi Pose",
      outfitPres: "Pelestarian Pakaian",
      lightQual: "Pencocokan Pencahayaan & Kualitas",
      detailLevel: "Tingkat Detail Prompt",
      levels: {
        basic: "Dasar",
        detailed: "Rinci",
        ultra: "Sangat Rinci"
      },
      tabs: {
        combined: "Prompt Siap Pakai",
        main: "Prompt Utama",
        negative: "Negative Prompt",
        frey: "Kunci Frey"
      },
      ready: "Siap",
      running: "Memproses...",
      waiting: "Menunggu Input",
      waitDesc: "Data akan muncul di sini setelah proses analisis gambar selesai.",
      copyAll: "Salin Semua",
      copyContent: "Salin Konten"
    },
    export: {
      profile: "Profil Engine",
      btn: "EKSPOR JSON",
      variation: "VARIASI BARU"
    },
    footer: {
      rights: "© 2026 VELDIFY ENGINE LAB",
      tagline: "PLATFORM REKAYASA PROMPT PRESISI",
      stable: "Engine Neural: Stabil",
      privacy: "Kebijakan Privasi",
      terms: "Syarat Layanan"
    }
  }
};

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string) => string;
}

export const LanguageContext = createContext<LanguageContextType>({
  lang: 'en',
  setLang: () => {},
  t: () => '',
});

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [lang, setLang] = useState<Language>('id'); // Default to ID based on request

  const t = (key: string) => {
    const keys = key.split('.');
    let value: any = translations[lang];
    for (const k of keys) {
      if (value) value = value[k];
    }
    return value || key;
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
