import { useLanguage } from "../i18n";

export function Footer() {
  const { t } = useLanguage();
  return (
    <footer className="w-full px-8 py-4 border-t border-border-dark bg-primary-black text-[10px] tracking-widest text-text-secondary uppercase font-medium mt-12 relative z-10">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 md:gap-6 text-center md:text-left">
          <span>{t('footer.rights')}</span>
          <span className="hidden md:inline text-border-dark">|</span>
          <span>{t('footer.tagline')}</span>
        </div>
        <div className="flex flex-wrap items-center justify-center md:justify-end gap-4 md:gap-6">
          <span className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
            {t('footer.stable')}
          </span>
          <a href="#" className="hover:text-white transition-colors">{t('footer.privacy')}</a>
          <a href="#" className="hover:text-white transition-colors">{t('footer.terms')}</a>
        </div>
      </div>
    </footer>
  );
}
