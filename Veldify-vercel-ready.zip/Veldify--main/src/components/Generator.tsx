import { useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Icons } from "./Icons";
import { OutputResult } from "../types";
import { useLanguage } from "../i18n";

export function Generator({ result, loading, onUpload, onVariation }: { result: OutputResult | null, loading: boolean, onUpload: (file: File, detailLevel: string, controls: any) => void, onVariation: (detailLevel: string, controls: any) => void }) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"combined" | "main" | "negative" | "frey">("combined");
  const [detailLevel, setDetailLevel] = useState<"basic" | "detailed" | "ultra">("ultra");
  const [controls, setControls] = useState({
    face: 100,
    pose: 100,
    outfit: 85,
    lighting: 90
  });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const { t } = useLanguage();

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    showToast(`${label} Copied!`);
  };

  const handleFile = (file: File) => {
    if (!file.type.startsWith("image/")) return;
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    onUpload(file, detailLevel, controls);
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="relative z-10 max-w-7xl mx-auto px-6 py-12 flex flex-col lg:flex-row gap-6 w-full" id="generator-section">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 20, x: "-50%" }}
            className="fixed bottom-10 left-1/2 z-50 bg-accent-blue text-white px-6 py-3 rounded-lg shadow-lg flex items-center gap-2 text-sm font-semibold tracking-wide"
          >
            <Icons.Check className="w-4 h-4" />
            {toastMessage}
          </motion.div>
        )}
      </AnimatePresence>

      {/* LEFT PANEL: Input & Analysis */}
      <section className="w-full lg:w-[380px] flex flex-col gap-5">
        
        {/* Upload Area */}
        <div 
          onClick={() => !loading && fileInputRef.current?.click()}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onDrop={onDrop}
          className={`bg-secondary-black border rounded-2xl p-6 flex flex-col items-center justify-center relative min-h-[200px] overflow-hidden transition-all ${isDragging ? 'border-accent-blue bg-accent-blue/10 border-solid' : 'border-border-dark border-dashed hover:border-text-secondary/50'} ${loading ? 'opacity-80 cursor-not-allowed border-solid' : 'cursor-pointer'}`}
        >
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="image/jpeg, image/png, image/webp" 
            onChange={(e) => {
              if (e.target.files?.[0]) handleFile(e.target.files[0]);
            }}
          />
          <AnimatePresence mode="wait">
            {previewUrl ? (
              <motion.div 
                key="preview"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 w-full h-full"
              >
                <img src={previewUrl} alt="Reference" className="w-full h-full object-cover opacity-60" />
                {loading && (
                  <div className="absolute inset-0 bg-primary-black/60 backdrop-blur-[2px] flex flex-col items-center justify-center">
                    <Icons.Loader2 className="w-8 h-8 text-accent-blue animate-spin mb-3" />
                    <span className="font-mono text-xs font-bold text-accent-blue uppercase tracking-widest">{t('gen.running')}</span>
                  </div>
                )}
                {!loading && result && (
                  <div className="absolute top-3 right-3 flex gap-2">
                    <div className="px-2 py-0.5 rounded bg-green-500/10 text-green-500 text-[10px] font-bold uppercase tracking-wider backdrop-blur-sm">{t('gen.ready')}</div>
                  </div>
                )}
              </motion.div>
            ) : (
               <motion.div 
                key="upload"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center text-center relative z-10"
              >
                <div className="w-12 h-12 bg-accent-blue/10 rounded-full flex items-center justify-center mb-4 transition-transform group-hover:scale-110">
                  <Icons.Upload className="w-5 h-5 text-accent-blue" />
                </div>
                <p className="text-sm font-medium">{t('gen.drop')}</p>
                <p className="text-xs text-text-secondary mt-1">{t('gen.supported')}</p>
              </motion.div>
            )}
           </AnimatePresence>
        </div>

        {/* Feature Detection */}
        <div className="bg-secondary-black border border-border-dark rounded-2xl p-5">
          <h3 className="text-xs font-bold text-text-secondary uppercase tracking-widest mb-4 flex items-center justify-between">
             {t('gen.scan')}
             <span className="text-accent-blue lowercase italic font-normal normal-case">{t('gen.engine')}</span>
          </h3>
          <div className="space-y-3 relative">
             <AnimatePresence>
               {result && (
                 <motion.div 
                   className="absolute inset-0 z-0 bg-green-500/5 rounded-xl pointer-events-none"
                   initial={{ opacity: 0 }}
                   animate={{ opacity: 1 }}
                   transition={{ duration: 1 }}
                 />
               )}
             </AnimatePresence>
             {[
               { label: t('gen.framingLock'), active: !!result },
               { label: t('gen.povLock'), active: !!result },
               { label: t('gen.faceIdentity'), active: !!result },
               { label: t('gen.skinRealism'), active: !!result },
               { label: t('gen.expressionLock'), active: !!result },
               { label: t('gen.hairGeo'), active: !!result },
               { label: t('gen.outfitTex'), active: !!result },
               { label: t('gen.poseLang'), active: !!result },
               { label: t('gen.rawPhoto'), active: !!result }
             ].map((feature, i) => (
                <motion.div 
                  key={i} 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: feature.active ? i * 0.15 : 0 }}
                  className="flex items-center justify-between text-sm relative z-10 py-1"
                >
                  <div className="flex items-center gap-3">
                    <div className={`relative flex items-center justify-center w-3 h-3`}>
                      <div className={`absolute inset-0 rounded-full ${feature.active ? 'bg-green-500/20 animate-ping' : ''}`}></div>
                      <div className={`w-2 h-2 rounded-full relative z-10 ${feature.active ? 'bg-green-500 shadow-[0_0_8px_#22c55e]' : 'bg-border-dark'}`}></div>
                    </div>
                    <span className={`transition-colors duration-500 ${feature.active ? 'text-white font-medium' : 'text-text-secondary'}`}>{feature.label}</span>
                  </div>
                  <motion.span 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: feature.active ? (i * 0.15) + 0.3 : 0 }}
                    className={`text-xs font-mono ${feature.active ? 'text-green-400 font-bold' : 'text-text-secondary'}`}
                  >
                    {feature.active ? '100%' : '---'}
                  </motion.span>
                </motion.div>
             ))}
          </div>
        </div>

        {/* Sliders */}
        <div className="bg-secondary-black border border-border-dark rounded-2xl p-5 flex-1 flex flex-col">
          <h3 className="text-xs font-bold text-text-secondary uppercase tracking-widest mb-5">{t('gen.control')}</h3>
          <div className="space-y-6">
            {[
              { id: 'face', label: t('gen.faceCons'), value: controls.face },
              { id: 'pose', label: t('gen.poseCons'), value: controls.pose },
              { id: 'outfit', label: t('gen.outfitPres'), value: controls.outfit },
              { id: 'lighting', label: t('gen.lightQual'), value: controls.lighting }
            ].map((setting) => (
              <div key={setting.id} className="space-y-2">
                <div className="flex justify-between text-xs font-medium">
                  <span className={!!result ? "text-white" : "text-text-secondary"}>{setting.label}</span>
                  <span className="text-accent-blue">{setting.value}%</span>
                </div>
                <div className="relative h-1.5 w-full bg-border-dark rounded-full overflow-hidden flex items-center group">
                  <div className="absolute top-0 left-0 h-full bg-accent-blue pointer-events-none transition-all duration-100 ease-out" style={{ width: `${setting.value}%` }}></div>
                  <input 
                    type="range"
                    min="0"
                    max="100"
                    value={setting.value}
                    onChange={(e) => setControls({...controls, [setting.id]: parseInt(e.target.value)})}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-8 pt-5 border-t border-border-dark">
            <h4 className="text-[10px] font-bold text-text-secondary uppercase tracking-widest mb-3">{t('gen.detailLevel')}</h4>
            <div className="grid grid-cols-3 gap-2">
              {(["basic", "detailed", "ultra"] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => setDetailLevel(level)}
                  className={`text-[10px] font-bold uppercase tracking-wider py-2 rounded transition-colors border ${
                    detailLevel === level 
                      ? 'bg-accent-blue/10 border-accent-blue/50 text-accent-blue' 
                      : 'bg-primary-black border-border-dark text-text-secondary hover:text-white hover:border-text-secondary'
                  }`}
                >
                  {t(`gen.levels.${level}`)}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* RIGHT PANEL: Output */}
      <section className="flex-1 flex flex-col gap-5">
        <div className="bg-secondary-black border border-border-dark rounded-2xl flex flex-col flex-1 overflow-hidden min-h-[500px]">
          
          {/* Tabs */}
          <div className="flex border-b border-border-dark bg-[#0F0F0F] overflow-x-auto custom-scrollbar">
            {[ 
              { id: 'combined', label: t('gen.tabs.combined') },
              { id: 'main', label: t('gen.tabs.main') }, 
              { id: 'negative', label: t('gen.tabs.negative') }, 
              { id: 'frey', label: t('gen.tabs.frey') }
            ].map((tab) => (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-6 py-4 text-xs font-bold uppercase tracking-widest whitespace-nowrap transition-colors ${activeTab === tab.id ? 'border-b-2 border-accent-blue text-accent-blue' : 'text-text-secondary hover:text-white border-b-2 border-transparent'}`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content Output */}
          <div className="p-6 flex-1 flex flex-col gap-4">
            {!result && !loading && (
              <div className="flex-1 flex flex-col items-center justify-center text-center">
                 <Icons.Image className="w-8 h-8 text-border-dark mb-4 filter drop-shadow-md" />
                 <p className="text-sm font-semibold text-text-secondary uppercase tracking-widest">{t('gen.waiting')}</p>
                 <p className="text-xs text-text-secondary opacity-60 mt-2 max-w-xs">{t('gen.waitDesc')}</p>
              </div>
            )}
            
            {loading && (
              <div className="flex-1 flex items-center justify-center">
                 <div className="flex gap-1.5">
                   {[...Array(3)].map((_, i) => (
                     <div key={i} className="w-2 h-2 bg-accent-blue rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                   ))}
                 </div>
              </div>
            )}

            {result && !loading && (
              <>
                <div className="relative flex-1 group min-h-[200px]">
                  <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                    <button 
                      onClick={() => copyToClipboard(
                        activeTab === 'combined' ? result.combinedPrompt :
                        activeTab === 'main' ? result.mainPrompt : 
                        activeTab === 'negative' ? result.negativePrompt : 
                        result.freyParameters.join("\n"), 
                        activeTab.toUpperCase()
                      )}
                      className="p-2 bg-border-dark rounded-md hover:bg-[#323238] text-text-secondary hover:text-white transition-colors flex items-center gap-2 px-3"
                      title={t('gen.copyContent')}
                    >
                      <Icons.Copy className="w-4 h-4" />
                      <span className="text-xs font-bold font-sans uppercase">{t('gen.copyAll')}</span>
                    </button>
                  </div>
                  
                  <div className="absolute inset-0 p-5 rounded-xl bg-primary-black border border-border-dark overflow-y-auto custom-scrollbar">
                    {activeTab === 'combined' && (
                      <div className="text-sm font-mono leading-relaxed text-[#D1D1D6] whitespace-pre-wrap">
                        <span className="text-white font-bold tracking-widest text-xs border-b border-border-dark pb-1 mb-3 inline-block uppercase">Siap Pakai (Copy & Paste)</span><br/><br/>
                        {result.combinedPrompt}
                      </div>
                    )}
                    {activeTab === 'main' && (
                      <div className="text-sm font-mono leading-relaxed text-[#D1D1D6] whitespace-pre-wrap">
                        <span className="text-accent-blue font-bold tracking-widest text-xs">[PROMPT UTAMA]</span><br/><br/>
                        {result.mainPrompt.split(/(\[LOCK.*?\]|\[OUTFITLOCK.*?\])/g).map((part, i) => {
                          if (part.startsWith('[LOCK') || part.startsWith('[OUTFITLOCK')) {
                            return <span key={i} className="text-accent-red font-bold">{part}</span>;
                          }
                          return part;
                        })}
                      </div>
                    )}
                    {activeTab === 'negative' && (
                      <div className="text-sm font-mono leading-relaxed text-[#D1D1D6] whitespace-pre-wrap">
                        <span className="text-text-secondary font-bold tracking-widest text-xs uppercase">[NEGATIVE PROMPT]</span><br/><br/>
                        {result.negativePrompt}
                      </div>
                    )}
                    {activeTab === 'frey' && (
                      <div className="text-sm font-mono leading-relaxed text-[#D1D1D6] whitespace-pre-wrap">
                        <span className="text-accent-red font-bold tracking-widest text-xs uppercase">[PARAMETER KUNCI FREY]</span><br/><br/>
                        <ul className="space-y-3">
                          {result.freyParameters.map((param, idx) => {
                            const [key, ...values] = param.split(':');
                            const val = values.join(':').trim();
                            const isLock = key.toUpperCase().includes("LOCK");
                            return (
                              <li key={idx} className="flex items-start gap-2">
                                <span className="text-accent-red font-bold mt-0.5 text-xs">●</span>
                                <div>
                                  <span className={`font-bold ${isLock ? 'text-white' : 'text-text-secondary'}`}>{key}:</span>
                                  <span className="text-text-secondary ml-2">{val}</span>
                                </div>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>

                {/* Secondary Section: Key Parameters (Visible alongside text outputs) */}
                {activeTab !== 'frey' && (
                  <div className="min-h-[140px] bg-primary-black border border-border-dark rounded-xl p-5 overflow-y-auto custom-scrollbar flex-shrink-0">
                    <h4 className="text-[10px] font-bold text-accent-red uppercase tracking-[0.2em] mb-4">Parameter Kunci Frey (Active Locks)</h4>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-6 text-xs">
                       {result.freyParameters.slice(0, 6).map((param, idx) => {
                          const [key, ...values] = param.split(':');
                          const val = values.join(':').trim();
                          return (
                            <li key={idx} className="flex items-center gap-2 text-text-secondary truncate">
                              <span className="text-accent-red text-[8px]">●</span> 
                              <span className="truncate">{key}:</span> 
                              <span className="text-white truncate">{val}</span>
                            </li>
                          );
                       })}
                    </ul>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Export Bar */}
          <div className="bg-[#161618] px-6 py-4 border-t border-border-dark flex flex-col sm:flex-row gap-4 items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-[10px] text-text-secondary uppercase tracking-widest hidden sm:inline-block">{t('export.profile')}:</span>
              <div className="flex gap-2">
                <button className="px-3 py-1 bg-accent-blue/20 text-accent-blue border border-accent-blue/30 rounded text-[10px] font-bold uppercase transition-colors hover:bg-accent-blue hover:text-white flex items-center gap-1">
                  <Icons.Sparkles className="w-3 h-3" />
                  HYPER-REALISM V2
                </button>
              </div>
            </div>
            
            <div className="flex items-center gap-3 w-full sm:w-auto">
              {result && (
                <button 
                  onClick={() => onVariation(detailLevel, controls)}
                  disabled={loading}
                  className="flex flex-1 sm:flex-none items-center justify-center gap-2 px-6 py-2.5 bg-secondary-black text-white rounded-lg text-xs font-bold transition-all uppercase tracking-wide border border-border-dark hover:border-text-secondary hover:bg-border-dark disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Icons.RefreshCcw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                  {t('export.variation')}
                </button>
              )}
              <button 
                onClick={() => {
                  if(result) {
                    const blob = new Blob([JSON.stringify(result, null, 2)], { type: "application/json" });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'prompt-data.json';
                    a.click();
                    URL.revokeObjectURL(url);
                  }
                }}
                disabled={!result || loading}
                 className={`flex flex-1 sm:flex-none items-center justify-center gap-2 px-6 py-2.5 bg-white text-black rounded-lg text-xs font-bold transition-all uppercase tracking-wide border-2 border-transparent ${!result || loading ? 'opacity-50 cursor-not-allowed' : 'hover:bg-transparent hover:border-white hover:text-white'}`}
              >
                <Icons.FileJson className="w-4 h-4" />
                {t('export.btn')}
              </button>
            </div>
          </div>

        </div>
      </section>
    </div>
  );
}
