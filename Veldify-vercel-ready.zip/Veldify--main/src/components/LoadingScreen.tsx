import { motion } from "motion/react";
import { useEffect, useState } from "react";

export function LoadingScreen({ onComplete }: { onComplete: () => void }) {
  const [textIndex, setTextIndex] = useState(0);
  const loadingTexts = [
    "> Initializing Analysis Engine...",
    "> Booting FaceLock Module...",
    "> Calibrating Environment Scanners...",
    "> Ready."
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setTextIndex((prev) => {
        if (prev < loadingTexts.length - 1) {
          return prev + 1;
        }
        clearInterval(interval);
        setTimeout(() => onComplete(), 500);
        return prev;
      });
    }, 800);
    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-primary-black overflow-hidden">
      {/* Background grids */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 50% 50%, var(--color-border-dark) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
      
      {/* Red pulse glow */}
      <motion.div 
        animate={{ opacity: [0.3, 0.6, 0.3], scale: [1, 1.2, 1] }} 
        transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        className="absolute w-[40vw] h-[40vw] bg-accent-red/10 rounded-full blur-[120px]" 
      />

      <div className="relative z-10 flex flex-col items-center text-center">
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative inline-flex items-center gap-3 mb-8"
        >
          <div className="w-1 h-8 bg-accent-red" />
          <h1 className="text-3xl font-display font-bold tracking-widest text-text-primary">
            VELDIFY<span className="text-accent-blue"> ENGINE LAB</span>
          </h1>
        </motion.div>

        {/* Scanning line animation container */}
        <div className="w-64 h-16 relative border border-border-dark bg-secondary-black rounded-lg overflow-hidden flex items-center px-4">
          <motion.div 
            animate={{ top: ["0%", "100%", "0%"] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
            className="absolute left-0 w-full h-[2px] bg-accent-blue shadow-[0_0_8px_var(--color-accent-blue)]"
          />
          <span className="font-mono text-sm text-accent-blue truncate">
            {loadingTexts[textIndex]}
          </span>
        </div>
      </div>
    </div>
  );
}
