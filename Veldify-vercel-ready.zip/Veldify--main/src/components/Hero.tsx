import { motion } from "motion/react";
import { Icons } from "./Icons";
import { useLanguage } from "../i18n";

export function Hero({ onUploadClick }: { onUploadClick: () => void }) {
  const { t } = useLanguage();
  return (
    <div className="relative w-full overflow-hidden border-b border-border-dark bg-transparent py-20">
      {/* Background Effects */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vw] max-w-[800px] max-h-[800px] bg-accent-blue/10 rounded-full blur-[100px]" />
        <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-accent-red/10 rounded-full blur-[80px]" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded bg-secondary-black border border-border-dark mb-8 text-[10px] font-bold uppercase tracking-widest text-accent-blue shadow-lg">
            <span className="w-1.5 h-1.5 rounded-full bg-accent-blue animate-pulse" />
            {t('hero.badge')}
          </div>
          
          <h1 className="text-4xl md:text-5xl font-sans font-bold tracking-tight text-white mb-6 leading-tight uppercase">
            {t('hero.title1')}<br className="hidden md:block"/> {t('hero.title2')}
          </h1>
          
          <p className="text-sm md:text-base text-text-secondary mb-10 max-w-2xl mx-auto leading-relaxed">
            {t('hero.desc')}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={onUploadClick}
              className="w-full sm:w-auto px-6 py-3 rounded-lg bg-gradient-to-r from-accent-blue to-blue-800 shadow-lg shadow-blue-900/20 active:scale-95 transition-all text-white font-semibold flex items-center justify-center gap-2 text-sm"
            >
              <Icons.Upload className="w-4 h-4" />
              {t('hero.upload')}
            </button>
            <button className="w-full sm:w-auto px-6 py-3 rounded-lg bg-secondary-black border border-border-dark text-white hover:bg-border-dark font-semibold transition-all text-sm shadow-md">
              {t('hero.demo')}
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
