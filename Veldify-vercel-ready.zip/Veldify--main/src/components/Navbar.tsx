import { motion } from "motion/react";
import { Icons } from "./Icons";
import { useLanguage } from "../i18n";

export function Navbar() {
  const { lang, setLang, t } = useLanguage();

  return (
    <nav className="sticky top-0 z-40 w-full border-b border-border-dark bg-primary-black/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight text-white flex items-center gap-2 uppercase">
              Veldify <span className="text-accent-blue">Engine Lab</span>
            </span>
            <div className="h-[2px] w-full bg-accent-red mt-0.5"></div>
          </div>
        </div>
        
        <div className="hidden md:flex items-center gap-6 text-sm font-medium text-text-secondary">
          <a href="#" className="hover:text-white transition-colors">{t('nav.generator')}</a>
          <a href="#" className="hover:text-white transition-colors">{t('nav.templates')}</a>
          <a href="#" className="hover:text-white transition-colors">{t('nav.docs')}</a>
          <a href="#" className="hover:text-white transition-colors">{t('nav.pricing')}</a>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => setLang(lang === 'en' ? 'id' : 'en')}
            className="flex items-center gap-2 text-xs font-semibold text-text-secondary hover:text-white transition-colors bg-secondary-black border border-border-dark px-3 py-1.5 rounded-lg"
          >
            <Icons.Globe className="w-3.5 h-3.5" />
            {lang.toUpperCase()}
          </button>
        </div>
      </div>
    </nav>
  );
}
