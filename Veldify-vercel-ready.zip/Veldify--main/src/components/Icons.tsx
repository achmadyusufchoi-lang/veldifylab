import { Upload, Image as ImageIcon, Copy, Check, Info, Settings2, SlidersHorizontal, ChevronRight, FileJson, FileText, Loader2, Sparkles, AlertCircle, Globe, RefreshCcw } from "lucide-react";

export const Icons = {
  RefreshCcw,
  Upload,
  Image: ImageIcon,
  Copy,
  Check,
  Info,
  Settings2,
  SlidersHorizontal,
  ChevronRight,
  FileJson,
  FileText,
  Loader2,
  Sparkles,
  AlertCircle,
  Globe
};
